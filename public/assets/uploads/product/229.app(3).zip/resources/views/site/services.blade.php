@extends("layouts.site.master")

@section('content')
	<div class="header-in bg-custom d-flex align-items-center">
		<div class="container-sm container-md container-lg container-xl container-xxl">
		</div>
	</div>
	<div class="content">
		<div class="container-sm container-md container-lg container-xl container-xxl py-5">
			<div class="px-3 list-sd">
			@foreach($row as $service)
				<div class="row">
					<div class="col-xxl-3 col-lg-4 col-sm-6 p-1">
						<a href="{{'/service/'. $service->url}}" class="text-decoration-none">
							<div class="card shadow border-0 position-relative p-1">
								<div class="overlay shadow position-absolute">
									<span class="text-dark">
									{{jdate('Y/m/d',$service->created_at->timestamp)}}
									</span>
								</div>
								<div class="img-box">
									<img src="{{asset('assets/uploads/service/'.$service->image)}}" alt="{{$service->iamge_seo}}" class="">
								</div>
								<div class="title-box text-center">
									<h5 class="text-dark my-0">
										{{$service->title}}
									</h5>
								</div>
							</div>
						</a>
					</div>
					
				</div>
			@endforeach
			</div>
		</div>
	</div>
@endsection