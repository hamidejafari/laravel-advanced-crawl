@extends("layouts.site.master")

@section('content')
	<div class="header-in bg-custom d-flex align-items-center">
		<div class="container-sm container-md container-lg container-xl container-xxl">
		</div>
	</div>
	<div class="content faq py-5">
		<div class="container-sm container-md container-lg container-xl container-xxl">
			<div class="row px-4">
				<div class="col-xxl-3 col-xl-3 col-lg-3 col-md-4 col-sm-6 p-2">
					@include('site.contents.reportage.sidebar-reportage')
				</div>
				<div class="col-xxl-9 col-xl-9 col-lg-9 col-md-8 col-sm-12 p-2">
					@include('site.contents.faq')
				</div>
			</div>
		</div>
	</div>
</body>
@endsection

