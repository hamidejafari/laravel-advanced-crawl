<div class="dashboard">
	<?php include('dashboard/dashboard-search.php')?>
	<div class="alert alert-primary text-custom fw-bolder alert-dismissible fade mx-0 my-2 show" role="alert">
		دسته بندی ها بر حسب تشخیص لندیپر و موارد اعلام شده توسط رسانه اعلام شده است
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
	<?php include('dashboard/dashboard-table.php')?>
</div>