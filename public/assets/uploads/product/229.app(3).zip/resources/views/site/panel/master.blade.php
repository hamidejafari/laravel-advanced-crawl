<!doctype html>
<html lang="fa">
@include('layouts.site.blocks.head')

<body dir="rtl">

@include('layouts.site.blocks.menu')
 @php
                            $user2 = \Illuminate\Support\Facades\Auth::user();
                            $ordersNew = \App\Models\Order::where('user_id',@$user->id)->notifOrder()->count();
                        @endphp
    <div class="header-in bg-custom d-flex align-items-center">
        <div class="container-sm container-md container-lg container-xl container-xxl">
            <div class="px-3">
                <nav aria-label="breadcrumb" class="max-content float-start me-auto">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item">
                            <a href="/" class="text-white fw-bolder text-decoration-none">
                                خانه
                            </a>
                        </li>
                        <li class="breadcrumb-item text-white fw-bolder active" aria-current="page">
                           پنل کاربری
                        </li>
                    </ol>
                </nav>
                <ul class="max-content float-end d-flex px-0 my-0 ms-auto">
                    <li class="list-unstyled float-end ms-sm-5">
                        <p class="m-0 text-white fw-bolder">
                            اعتبار : <span class="text-custom-danger">{{number_format($user2->wallet)}}</span> تومان
                        </p>
                    </li>
                    <li class="list-unstyled float-end ms-sm-5">
                        <p class="m-0 text-white fw-bolder">
                           {{ $user2->name . ' ' . $user2->family }}
                        </p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<div class="content">
    <div class="container-sm container-md container-lg container-xl container-xxl">
        <div class="row">
            <div class="col-xxl-2 col-xl-2 col-lg-2 col-md-2 col-sm-6 p-2">
                <div class="sidebar position-sticky sticky">
                    <ul class="px-0 m-0">
                        <li class="list-unstyled pb-2">
                            <a href="{{route('site.panel.dashboard')}}" class="d-flex text-decoration-none d-flex align-items-center">
                                <i class="fas fa-wallet text-custom-danger me-3"></i>
                                <span class="text-custom fw-bolder">
                                    داشبورد
                                </span>
                            </a>
                        </li>
                       
                        <li class="list-unstyled pb-2">
                            <a href="{{route('site.panel.orders')}}" class="d-flex text-decoration-none d-flex align-items-center">
                                <i class="fas fa-shopping-bag text-custom-danger me-3"></i>
                                <span class="text-custom fw-bolder">
                                        سفارشات
                                    </span>
                                <sapn class="badge bg-custom-danger ms-auto rounded-pill">
                                    {{$ordersNew}}
                                </sapn>
                            </a>
                        </li>
                        <li class="list-unstyled pb-2">
                            <a href="{{route('site.panel.charge')}}" class="d-flex text-decoration-none d-flex align-items-center">
                                <i class="fas fa-plus-circle text-custom-danger me-3"></i>
                                <span class="text-custom fw-bolder">
                                    افزایش اعتبار
                                </span>
                            </a>
                        </li>
                        <li class="list-unstyled pb-2">
                            <a href="{{route('site.panel.profile')}}" class="d-flex text-decoration-none d-flex align-items-center">
                                <i class="fas fa-info-circle text-custom-danger me-3"></i>
                                <span class="text-custom fw-bolder">
                                    اطلاعات کاربری
                                </span>
                            </a>
                        </li>

{{--                        <li class="list-unstyled pb-2">--}}
{{--                            <a href="tickets.php" class="d-flex text-decoration-none d-flex align-items-center">--}}
{{--                                <i class="fas fa-headset text-custom-danger me-3"></i>--}}
{{--                                <span class="text-custom fw-bolder">--}}
{{--                                    تیکت ها--}}
{{--                                </span>--}}
{{--                                <sapn class="badge bg-custom-danger ms-auto rounded-pill">--}}
{{--                                    ۹۸--}}
{{--                                </sapn>--}}
{{--                            </a>--}}
{{--                        </li>--}}
                        <li class="list-unstyled pb-2">
                            <a href="{{route('site.panel.logout')}}" class="d-flex text-decoration-none d-flex align-items-center">
                                <i class="fas fa-power-off text-custom-danger me-3"></i>
                                <span class="text-custom fw-bolder">
                                    خروج
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xxl-10 col-xl-10 col-lg-10 col-md-10 col-sm-12 p-2">
                @yield('content')
            </div>
        </div>
    </div>
</div>
@include('layouts.site.blocks.footer')
@include('layouts.site.blocks.script')
@include('layouts.site.blocks.message')
</body>

</html>
