@extends("layouts.admin.master")

@section('content')
   
@include('layouts.admin.blocks.content')


@endsection