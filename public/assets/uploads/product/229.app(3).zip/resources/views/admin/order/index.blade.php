@extends("layouts.admin.master")
@section('content')
    <div class="row">
        <div class="col-md-12 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">لیست سفارشات </h3>

                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover">
                        <tr>
                            <th>شماره</th>
                            <th>کاربر</th>
                            <th>مبلغ کل</th>
                            <th>تعداد ایتم</th>
                            <th>وضعیت</th>
                            <th>عملیات</th>
                        </tr>
                        @foreach($data as $row)
                            @if($row->order_status_id == 3)
                                <tr style="background-color: #00d80026;">
                            @else
                                <tr>
                            @endif
                                <td>{{$row->id}}</td>
                                <td>{{$row->user->name .' '. $row->user->family}}</td>
                                <td>{{number_format($row->total_prices) . ' تومان '}}</td>
                                <td>{{count($row->orderItems)}}</td>
                                <td>{{$row->orderStatus->title}}</td>
                                <td>
                                    <a href="{{url('/admin/order/detail/'.$row->id)}}" type="button" class="btn btn-primary">مشاهده جزییات</a>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                    <div class="pagii">
                        @if(count($data))
                            {!! $data->appends(Request::except('page'))->render() !!}
                        @endif
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
    </div>
@endsection
