<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Library\Help;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Kavenegar\Exceptions\ApiException;
use Kavenegar\Exceptions\HttpException;
use Kavenegar\KavenegarApi;

class AuthController extends Controller
{
    public function register()
    {
        return view('site.auth.register');
    }
    public function postRegister(RegisterRequest $request){
        // $code = random_int(100000, 999999);
        $code = 123456;
        $user = User::create([
            'name'=>$request->get('name'),
            'family'=>$request->get('family'),
            'email'=>$request->get('email'),
            'mobile'=>Help::persian2LatinDigit($request->get('mobile')),
            'mobile_confirm_code'=>$code,
            'password'=>bcrypt($request->get('password')),
            'admin'=>0
        ]);
        auth()->login($user);
        return redirect()->route('site.panel.mobile-confirm');
    }
    public function login(){
        return view('site.auth.login');
    }
    public function postLogin(LoginRequest $request){
        $login = Auth::attempt([
            'mobile' => $request->get('mobile'),
            'password' => Help::persian2LatinDigit($request->get('password'))
        ]);
        if ($login) {
            return redirect()->route('site.panel.dashboard');
        }
        return redirect()->back()->with('error', 'اطلاعات ورود اشتباه می باشد.');
    }

    public function forgetPassword(){
        return view('site.auth.forget-password');
    }
    public function postForgetPassword(Request $request){
        $check = User::where('mobile',Help::persian2LatinDigit($request->mobile))->first();
        if(!$check){
            return redirect()->back()->with('error','شماره همراه در سامانه موجود نمیباشد.');
        }
        $code = random_int(100000, 999999);
        $check->update(['password'=>bcrypt($code)]);
        return redirect('/login2/')->with('success','با رمز عبور ارسال شده به شماره همراهتان وارد پنل کاربری شوید.');
    }
}
