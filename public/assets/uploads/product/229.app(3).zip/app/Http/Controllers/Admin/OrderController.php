<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\ServiceRequest;
use App\Models\Content;

class OrderController extends Controller
{
    public function getIndex(){
        $data = Order::paginate(15);
        return view('admin.order.index')
            ->with('data' , $data);
    }

    public function getDetail($id){
        $data = Order::find($id);
        $status_item = OrderStatus::where('type',2)->get();
        $status_order = OrderStatus::where('type',1)->get();
        return view('admin.order.detail')
            ->with('status_item' , $status_item)
            ->with('status_order' , $status_order)
            ->with('data' , $data);
    }
    public function postChange(Request $request){
        $input = $request->all();
        if($input['type'] == 2){
            $orderItem = OrderItem::find($input['order_item_id'])->update($input);
        }else{
            $order = Order::find($input['order_id'])->update([$input]);
        }
        return redirect()->back()->with('success','با موفقیت ویرایش شد');
    }
}
