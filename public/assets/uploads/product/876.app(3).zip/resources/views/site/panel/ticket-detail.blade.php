@extends("site.panel.master")
@section('content')
    <div class="border dashboard-search p-4 mb-0">
        <h4 class="text-custom text-center mb-4">
            جزییات تیکت
        </h4>
        <div class="row w-100 m-0">
            <div style="margin-right: 20%;margin-bottom: 3%;" class="col-xxl-7 col-lg-7 col-sm-12 p-2" >
                <div class="well-l chatroom">
                    <div class="card card-chat rounded m-auto">
                    <form action="{{route('site.panel.ticket.reply')}}" method="post" class="m-0"  enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="row w-100 m-0" style="padding:1vh 0 2vh">

                            <div class="col-sm-12 p-1">
                                <div class="bg-light max-cuntent right-chat shadow-sm" style="background:#eee">
                                    <h5 class="font-weight-bold" style="margin:0">
                                       {{ @$ticket->user->name . ' ' . @$ticket->user->family }}
                                    </h5>
                                    <hr style="margin: 10px;">

                                    <div class="text-dark text-justify">
                                        <p class="m-0" style="white-space: pre-line;margin-right: 4% !important;">
                                          {{$ticket->content}}
                                        </p>
                                    </div>
                                    <hr style="margin: 10px;">

                                    <small class="text-secondary smal">
                                        {{jdate('Y/m/d H:i',$ticket->created_at->timestamp)}}
                                    </small>
                                </div>
                            </div>

                            @foreach($ticket->replies as $row)
                                @if($row->user_id == Auth::id())
                                    <div class="col-sm-12 p-1">
                                        <div class="bg-light max-cuntent right-chat shadow-sm" style="background:#eee">
                                            <h5 class="font-weight-bold" style="margin:0">
                                                {{ @$row->user->name . ' ' . @$row->user->family }}
                                            </h5>
                                            <hr style="margin: 10px;">

                                            <div class="text-dark text-justify">
                                                <p class="m-0" style="white-space: pre-wrap;margin-top: -15% !important;margin-bottom: -7% !important;margin-right: 4% !important;">
                                                    {{$row->content}}
                                                </p>
                                            </div>
                                            <hr style="margin: 10px;">

                                            <small class="text-secondary smal">
                                                {{jdate('Y/m/d H:i',$row->created_at->timestamp)}}
                                            </small>
                                        </div>
                                    </div>
                                @else
                                    <div class="col-sm-12 p-1">
                                        <div class="bg-light max-cuntent left-chat shadow-sm" style="background:#eee">
                                            <h5 class="font-weight-bold" style="margin:0">
                                                پشتیبانی لندیپر
                                            </h5>
                                            <hr style="margin: 10px;">
                                            <div class="text-dark text-justify">
                                                <p class="m-0" style="white-space: pre-wrap;margin-top: -15% !important;margin-bottom: -7% !important;margin-right: 4% !important;">
                                                    {{$row->content}}
                                                </p>
                                            </div>
                                            <hr style="margin: 10px;">
                                            <small class="text-secondary smal">
                                                {{jdate('Y/m/d H:i',$row->created_at->timestamp)}}
                                            </small>
                                        </div>
                                    </div>
                                @endif
                            @endforeach

                        </div>
                        <div class="position-absolute input-box">
                            <div class="bg-white m-0 rounded-0 border" style="position: relative;">
                                <input type="hidden" name="reply_id" value="{{$ticket->id}}" />
                                <textarea class="form-control border-0" name="content" id=""
                                          placeholder="نوشتن پیام"></textarea>
                                <input type="submit" value="ارسال"
                                       class="btn btn-custom btn-success rounded-0" style="position: absolute;">
                            </div>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>

    </div>

@endsection
@section('css')
    <style>
        .chatroom {
            background: #FFF
        }

        .chatroom .card-chat {
            padding: 1vh 1vh 7vh 1vh;
        }

        .chatroom .input-box {
            bottom: 0;
            left: 0;
            right: 0;
            background: #ddd;
            height: 6vh;
        }

        .chatroom .input-box textarea {
            height: 6vh;
        }

        .chatroom .right-chat {
            margin-left: auto;
            border-radius: 2vh 0 2vh 2vh;
        }

        .chatroom .left-chat {
            margin-right: auto;
            border-radius: 0 2vh 2vh 2vh;
            text-align: left
        }

        .chatroom .max-cuntent {
            width: 50%;
            box-shadow: 0 0 5px 0 rgba(0, 0, 0, .15);
            padding: 1.5vh;
        }

        .chatroom .max-cuntent .smal {
            padding: 1.5vh 0 0 0;
            display: flex;
            font-size: 1.5vh;
        }

        .chatroom .btn-custom {
            left: 0;
            top: 0;
            bottom: 0;
            margin: 0
        }
    </style>
@stop
