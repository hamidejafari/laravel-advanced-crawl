@extends("site.panel.master")
@section('content')
    <div class="dashboard">
        <div class="border dashboard-search p-4 mb-2">
            <h4 class="text-custom text-center mb-4">
                جستجوی پیشرفته رپورتاژ
            </h4>
            <form method="get" action="{{URL::current()}}" class="m-0">
                <input name="search"  value="1" type="hidden" />
                <input type="hidden" name="order_item_id" value="{{@$order_item_id}}"/>

                <div class="row w-100 m-0">
                    <div class="col-xxl-4 col-xl-5 col-lg-6 p-0">
                        <div class="row w-100 m-0">
                            <div class="col-xxl-6 col-lg-12 col-sm-6 p-1">
                                <label for="" class="text-secondary d-flex align-items-center">
                                    حداقل اتوریتی
                                </label>
                                <input type="number" name="da" id="" class="form-control"  placeholder="45" value="{{ $da ? $da : '' }}">
                            </div>
                            <div class="col-xxl-6 col-lg-12 col-sm-6 p-1">
                                <label for="" class="text-secondary d-flex align-items-center">
                                    حداکثر قیمت (تومان)
                                </label>
                                <input type="number" name="price" id="" class="form-control"  placeholder="1,000,000" value="{{ $price ? $price : '' }}">
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-8 col-xl-7 col-lg-6 p-0">
                        <div class="row w-100 m-0">
                            <div class="col-xxl-4 col-lg-12 col-sm-4 p-1">
                                <div class="position-relative sc">
                                    <div class="position-absolute top-0 end-0 start-0" style="z-index: 99;">
                                        <label for="" class="text-secondary d-flex align-items-center">
                                            انتخاب موضوع
                                        </label>
                                        <button class="btn form-select border select" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapse3"
                                                aria-expanded="false" aria-controls="collapse3">
                                            انتخاب کنید
                                        </button>
                                        <div class="collapse" id="collapse3">
                                            <div class="card card-body p-2">
                                                @foreach($categories as $row)
                                                    <div class="form-check py-1">
                                                        <input class="form-check-input " name="category_id[]" type="checkbox" @if($category_id && in_array($row->id,$category_id)) checked @endif  value="{{$row->id}}" id="flexCheckDefault">
                                                        <label class="form-check-label" for="flexCheckDefault">
                                                            {{$row->title}}
                                                        </label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-lg-12 col-sm-4 p-1">
                                <div class="position-relative sc">
                                    <div class="position-absolute top-0 end-0 start-0" style="z-index: 99;">
                                        <label for="" class="text-secondary d-flex align-items-center">
                                            انتخاب کشور
                                        </label>
                                        <button class="btn form-select border select" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapse1"
                                                aria-expanded="false" aria-controls="collapse1">
                                            انتخاب کنید
                                        </button>
                                        <div class="collapse" id="collapse1">
                                            <div class="card card-body p-2">
                                                @foreach($countries as $row)
                                                    <div class="form-check py-1">
                                                        <input class="form-check-input " name="country_id[]" type="checkbox" @if($country_id &&  in_array($row->id,$country_id) ) checked @endif  value="{{$row->id}}" id="flexCheckDefault3">
                                                        <label class="form-check-label" for="flexCheckDefault3">
                                                            {{$row->title}}
                                                        </label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-4 col-lg-12 col-sm-4 p-1">
                                <div class="position-relative sc">
                                    <div class="position-absolute top-0 end-0 start-0" style="z-index: 99;">
                                        <label for="" class="text-secondary d-flex align-items-center">
                                            انتخاب زبان رسانه
                                        </label>
                                        <button class="btn form-select border select" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapse2"
                                                aria-expanded="false" aria-controls="collapse2">
                                            انتخاب کنید
                                        </button>
                                        <div class="collapse" id="collapse2">
                                            <div class="card card-body p-2">
                                                @foreach($languages as $row)
                                                    <div class="form-check py-1">
                                                        <input class="form-check-input " name="language_id[]" type="checkbox" @if($language_id && in_array($row->id,$language_id) ) checked @endif  value="{{$row->id}}" id="flexCheckDefault2">
                                                        <label class="form-check-label" for="flexCheckDefault2">
                                                           {{$row->title}}
                                                        </label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
{{--                    <div class="col-xxl-3 col-lg-12 col-sm-4 p-1">--}}
{{--                        <label for="" class="text-secondary d-flex align-items-center">--}}
{{--                             <input type="radio" id="other" name="sort" value="sort_number|desc" @if((@$sort[0] == "sort_number" && @$sort[1] == "desc")) checked="" @endif style="margin-left: 4px;">ترتیب بر اساس نظر کارشناس--}}
{{--                        </label>--}}
{{--                    </div>--}}
                    <div class="col-xxl-3 col-lg-12 col-sm-4 p-1">
                        <label for="" class="text-secondary d-flex align-items-center">
                            <input type="radio" id="other" name="sort" value="da|desc" @if(@$sort[0] == "da" && @$sort[1] == "desc")) checked="" @endif  style="margin-left: 4px;">ترتیب  بر اساس DA
                        </label>
                    </div>
                    <div class="col-xxl-3 col-lg-12 col-sm-4 p-1">
                        <label for="" class="text-secondary d-flex align-items-center">
                            <input type="radio" id="other" name="sort" value="dr|desc" @if((@$sort[0] == "dr" && @$sort[1] == "desc")) checked="" @endif  style="margin-left: 4px;">ترتیب  بر اساس DR
                        </label>
                    </div>
                    <div class="col-xxl-2 col-lg-12 col-sm-4 p-1">
                        <label for="" class="text-secondary d-flex align-items-center">
                            <input type="radio" id="other" name="sort" value="price|desc" @if((@$sort[0] == "price" && @$sort[1] == "desc")) checked="" @endif  style="margin-left: 4px;">ترتیب   بر اساس قیمت
                        </label>
                    </div>
                    <div class="col-xxl-12 col-xl-12 col-lg-12 ms-auto p-0">
                        <div class="row w-100 m-0">
                            <div class="col-xxl-3 col-xl-12 ms-auto p-1" style="margin: 0px !important;">
                                <button type="submit"
                                        class="btn w-100 btn-custom-danger rounded-3 d-flex align-items-center justify-content-center">
                                    <i class="fas fa-search me-3"></i>
                                    جستجوی رپورتاژ
                                </button>
                                @if($search)
                                <a href="{{url('/panel')}}" style="width: 53% !important;font-size: 10px;margin-top: 3%;margin-right: 24%;text-align: center;background-color: #8a8989;"
                                        class="btn w-100 btn-custom-danger rounded-3 d-flex align-items-center justify-content-center">
                                   پاک کردن جستجو
                                </a>
                                    @endif
                            </div>
                        </div>
                    </div>
                </div>

        </div>
        <div class="alert alert-primary text-custom fw-bolder alert-dismissible fade mx-0 my-2 show" role="alert">
            دسته بندی ها بر حسب تشخیص لندیپر و موارد اعلام شده توسط رسانه اعلام شده است
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <div class="border dashboard-table p-2 mb-2">
            <table class="table table-striped m-0">
                <thead>
                <tr>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        DA

                        @if((@$sort[0] == "da" && @$sort[1] == "asc"))
                        <button type="submit" value="da|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>
                        @elseif(@$sort[0] == "da" && @$sort[1] == "desc")
                            <button type="submit" value="da|asc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-up me-3"></i></button>
                        @else
                            <button type="submit" value="da|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>

                        @endif
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        DR

                        @if(@$sort[0] == "dr" && @$sort[1] == "asc")
                            <button type="submit" value="dr|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>
                        @elseif(@$sort[0] == "dr" && @$sort[1] == "desc")
                            <button type="submit" value="dr|asc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-up me-3"></i></button>
                        @else
                            <button type="submit" value="dr|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>
                        @endif
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        کشور
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        زبان
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        دامنه
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        قیمت

                        @if(@$sort[0] == "price" && @$sort[1] == "asc")
                            <button type="submit" value="price|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>
                        @elseif(@$sort[0] == "price" && @$sort[1] == "desc")
                            <button type="submit" value="price|asc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-up me-3"></i></button>
                        @else
                            <button type="submit" value="price|desc" name="sort" style="background: none !important;border: none !important;color: blue;"><i class="fas fa-arrow-down me-3"></i></button>
                        @endif
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        موضوع
                    </th>
                    <th scope="col" class="text-center text-custom fw-bolder">
                        افزودن به سبد
                    </th>
                </tr>
                </form>
                </thead>
                <tbody>
                @foreach($products as $row)
                    <tr>
                        <th class="text-center" scope="row">
                            {{$row->da}}
                        </th>
                        <th class="text-center" scope="row">
                            {{$row->dr}}
                        </th>
                        <td class="text-center">
                            {{@$row->country->title}}
                        </td>
                        <td class="text-center">
                            {{@$row->language->title}}
                        </td>
                        <td class="text-center">
                            <a target="_blank" href="{{$row->domain}}">{{$row->domain}}</a>
                        </td>

                        <td class="text-center">
                            {{number_format(intval($row->price))}} تومان
                        </td>
                        <td class="text-center">
                            @foreach($row->categories as $item)
                                {{@$item->title}}
                                <br>
                            @endforeach
                        </td>
                        <td class="text-center">

                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-custom-danger rounded-3" data-bs-toggle="modal" data-bs-target="#orderModal{{$row->id}}">
                                <i class="fas fa-shopping-bag"></i>
                            </button>

                        </td>
                    </tr>
                @endforeach

                </tbody>
            </table>


        </div>

        <center>
            <!--{{ $products->links() }}-->
           {{ $products->appends(request()->input())->render() }}
        </center>
    </div>



    @foreach($products as $row)


        <!-- Modal -->
        <div class="modal fade" id="orderModal{{$row->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form method="post" action="{{route('site.panel.order.post-add')}}" enctype="multipart/form-data" >
                    <input type="hidden" name="product_id" value="{{$row->id}}"/>
                    <input type="hidden" name="order_item_id" value="{{@$order_item_id}}"/>
                    {{csrf_field()}}
                    <div class="modal-content" style="width: 939px;
margin-right: -44%;">

                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">    ثبت رپورتاژ در رسانه "{{$row->domain}}"</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table table-hover" style="background: #dedede33;">
                                <tr>
                                    <th>زبان</th>
                                    <th>کشور</th>
                                    <th>موضوع</th>
                                    <th>اتوریتی</th>
                                    <th>قیمت</th>
                                    <th>سقف تعداد لینک</th>
                                    <th>سقف تعداد لینک های فالو </th>
                                    @if($row->requirements !== null)
                                    <th>شرایط درج رپورتاژ</th>
                                        @endif
                                </tr>
                                <tr>
                                    <td>{{@$row->language->title}}</td>
                                    <td> {{@$row->country->title}}</td>
                                    <td>
                                        @foreach($row->categories as $item)
                                            {{@$item->title}}
                                            <br>
                                        @endforeach
                                    </td>
                                    <td> {{$row->da}}</td>
                                    <td>{{number_format(intval($row->price))}}</td>

                                    @if($row->max_total_link !== null)
                                        <td> {{$row->max_total_link}}</td>

                                    @else
                                        <td>3</td>
                                    @endif


                                    @if($row->max_doffolow_link !== null)
                                        <td> {{$row->max_doffolow_link}}</td>

                                    @else
                                        <td>3</td>
                                    @endif

                                    @if($row->requirements !== null)
                                        <td>{{$row->requirements}}</td>

                                    @endif

                                </tr>

                            </table>



                            <div class="form-group col-md-12">
                                <label>نام کمپین :</label>
                                <input name="name" type="text" class="form-control" placeholder=" نام کمپین را وارد کنید..."
                                       value = "">
                            </div>
                            <br>
                            <div class="form-group col-md-12">
                                <label>عنوان  :</label>
                                <input name="title" type="text" class="form-control" placeholder=" عنوان رپورتاژ را وارد کنید..."
                                       value = "">
                            </div>
                            <br>
                            <div class="form-group">
                                <label>توضیحات :</label>
                                <textarea name="description" type="text" rows="5" cols="5" class="form-control" placeholder=" اگر توضیح و نکته ای در هنگام انتشار رپورتاژ دارید وارد نمایید."></textarea>
                            </div>
                            <br>

                            <div class="form-group col-md-12">
                                <p style="font-size: 12px;color: green;">
                                    فایل Word حاوی متن و لینک رپورتاژ های خود را وارد نمایید. لینک های خود را در Word به صورت Hyper Link در وسط متن، درج نمایید.
                                    <br>
                                    برای ارسال عکس، فایل Word و عکس ها را در یک فایل RAR آپلود نمایید.
                                </p>
                                <label> آپلود فایل</label>
                                <input type="file" class="form-control" name="file" id="exampleInputPassword1" placeholder="انتخاب فایل">
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">بستن</button>
                            <button type="submit" class="btn  btn-custom-danger rounded-3">اضافه کردن به سبد خرید</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


    @endforeach

    <style>
        .pagination {
            margin-right: 20%;
            margin-top: 4%;
        }
    </style>
@endsection
