<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollabl">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">نوشتن تیکت</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form class="row g-3">
					<div class="col-lg-6 col-sm-12">
						<label for="" class="form-label text-secondary">موضوع تیکت :</label>
						<input type="text" class="form-control" id="">
					</div>
					<div class="col-lg-6 col-sm-12">
						<label for="" class="form-label text-secondary">انتخاب کنید :</label>
						<select id="" class="form-select">
							<option selected>انتخاب</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
						</select>
					</div>
					<div class="col-sm-12">
						<label for="" class="form-label text-secondary">نوشتن تیکت :</label>
						<textarea name="" id="" cols="30" rows="4" class="form-control"></textarea>
					</div>
					<div class="col-sm-12 ">
						<button type="submit" class="btn btn-custom-danger d-flex align-items-center ms-auto">
							<i class="fas fa-paper-plane me-2"></i>
							ارسال تیکت
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>