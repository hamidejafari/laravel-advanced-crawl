<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Http\Requests\ConfirmMobileRequest;
use App\Http\Requests\OrderRequest;
use App\Models\Category;
use App\Models\Country;
use App\Models\Language;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Ticket;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\ProductCategory;
use App\Models\Transaction;

use App\Library\Help;

class PanelController extends Controller
{
    public function mobileConfirm(){
        return view('site.auth.mobile-confirm');
    }
    public function postMobileConfirm(ConfirmMobileRequest $request){
        $user = User::find(Auth::id());
        if($user->mobile_confirm_code === Help::persian2LatinDigit($request->get('code')) ){
            $user->update(['mobile_confirm'=>1]);
            return redirect()->route('site.panel.dashboard');
        }else{
            return redirect()->back()->with('error','کد فعال سازی معتبر نیست');
        }
    }
    public function dashboard(Request $request){
        $query = Product::query();
        $setting = Setting::first();
        if ($request->has('search')) {
            if ($request->get('price')) {
                $query->where('price', '<=', $request->get('price'));
            }
            if ($request->get('da')) {
                $query->where('da','>=', $request->get('da'));
            }
            if ($request->get('country_id')) {
                $query->whereIn('country_id', $request->get('country_id'));
            }
            if ($request->get('language_id')) {
                $query->whereIn('language_id', $request->get('language_id'));
            }
        }



        if ($request->has('search') && $request->has('category_id')) {
            $product_ids = ProductCategory::whereIn('category_id', $request->get('category_id'))->pluck('product_id')->toArray();
             $query->whereIn('id',$product_ids);
        }

        if($request->has('sortBy')){
            $data = $query->orderBy($request->get('sortBy'),'DESC')->whereHas('categories')->whereHas('country')->whereHas('language')->where('price','>',$setting->price_limit)->paginate(20);
        }else{
            $data = $query->orderBy('id','DESC')->whereHas('categories')->whereHas('country')->whereHas('language')->where('price','>',$setting->price_limit)->paginate(20);
        }



        $countries = Country::all();
        $languages = Language::all();

        $categories = Category::all();
        return view('site.panel.dashboard')
            ->with('order_item_id',@$request->get('order_item_id'))
            ->with('price',@$request->get('price'))
            ->with('da',@$request->get('da'))
            ->with('country_id',@$request->get('country_id'))
            ->with('language_id',@$request->get('language_id'))
            ->with('category_id',@$request->get('category_id'))

            ->with('sort_by',@$request->get('sortBy'))


            ->with('countries',$countries)
            ->with('languages',$languages)
            ->with('categories',$categories)
            ->with('products',$data);
    }
    public function postAddOrder(OrderRequest $request){
        $input = $request->all();
        $cartItem = OrderItem::find($input['order_item_id']);

        if($input['order_item_id'] !== null || $cartItem !== null){
            if($request->hasFile('file')){
                $pathMain = "assets/uploads/product/";
                $extension = $request->file('file')->getClientOriginalName();
                $fileName = mt_rand(100,900) . ".$extension";
                $request->file('file')->move($pathMain , $fileName);
                $input['file'] = $fileName;
            }
            $product = Product::find($request->product_id);
            $cartItem->update([
                'product_id' => $product->id,
                'name' => $input['name'],
                'title' => $input['title'],
                'description' => @$input['description'],
                'file' => @$input['file'],
                'order_item_status_id' =>8,
            ]);

            return redirect('/panel/order/detail/'.$cartItem->order_id)->with('success','ایتم جدید با موفقیت به سبد خرید شما اضافه شد.');

        }else{

            $currentOrder = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
            if($currentOrder == null){
                $currentOrder = Order::create([
                    'user_id' => auth()->user()->id,
                    'order_status_id' => 1
                ]);
            }


            $product = Product::find($request->product_id);
            $cartItem = OrderItem::whereOrderId($currentOrder->id)->whereProductId($product->id)->first();
            if($cartItem == null){
                if($request->hasFile('file')){
                    $pathMain = "assets/uploads/product/";
                    $extension = $request->file('file')->getClientOriginalName();
                    $fileName = mt_rand(100,900) . ".$extension";
                    $request->file('file')->move($pathMain , $fileName);
                    $input['file'] = $fileName;
                }
                $cartItem = OrderItem::create([
                    'product_id' => $product->id,
                    'name' => $input['name'],
                    'title' => $input['title'],
                    'description' => $input['description'],
                    'file' => $input['file'],
                    'order_id' => $currentOrder->id,
                    'order_item_status_id' =>8,
                ]);
            }

            $total_price = 0;
            $cartItems = OrderItem::whereOrderId($currentOrder->id)->with('product')->get();
            foreach($cartItems as $row){
                $total_price = $total_price+@$row->product->price;
            }

            $currentOrder->update([
                'total_prices'=>$total_price
            ]);
            return redirect('/panel')->with('success','ایتم جدید با موفقیت به سبد خرید شما اضافه شد.');
        }

    }
    public function orderStatus($id,$status){
        if($status == 16){
            $cartItem = OrderItem::find($id);
            $cartItem->update(['order_item_status_id'=>$status]);
            return redirect()->back()->with('success','ایتم مورد نظر با موفقیت لغو شد!');
        }else{
            return redirect()->back();
        }
    }
    public function postEditOrder(Request $request){
        $input = $request->all();
        $cartItem = OrderItem::find($input['order_item_id']);
        if($request->hasFile('file')){
            $pathMain = "assets/uploads/product/";
            $extension = $request->file('file')->getClientOriginalName();
            $fileName = mt_rand(100,900) . ".$extension";
            $request->file('file')->move($pathMain , $fileName);
            $input['file'] = $fileName;
        }
        $cartItem->update($input);
        return redirect()->back()->with('success','با موفقیت ویرایش شد.');
    }
    public function deleteOrder($id){
        $cartItem = OrderItem::find($id);
        $cartItem->delete();

        $total_price = 0;
        $currentOrder = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
        $cartItems = OrderItem::whereOrderId($currentOrder->id)->get();
        foreach($cartItems as $row){
            $total_price = $total_price+$row->product->price;
        }
        $currentOrder->update([
            'total_prices'=>$total_price
        ]);
        return redirect()->back()->with('success','آیتم با موفقیت حذف شد.');
    }
    public function cart(){
        $current_order = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
        // if(!$current_order){
        //     return redirect('/')->with('success','سبد خرید شما خالی است, ابتدا ایتم جدید به سبد اضافه کنید.');
        // }
        return view('site.panel.cart')
            ->with('current_order',@$current_order);
    }
    public function postCart(Request $request){
        $currentOrder = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
        $currentOrder->update(['order_status_id'=>3,'payment'=>$currentOrder->total_prices - auth()->user()->wallet]);

        return redirect('/panel/order/detail/'.$currentOrder->id)->with('success','با موفقیت انجام شد');
    }

    public function tickets(){
        $tickets = Ticket::where('user_id',Auth::id())->whereNull('reply_id')->get();
        return view('site.panel.tickets')->with('tickets',$tickets);
    }
    public function ticketDetail($id){
        $ticket = Ticket::find($id);
        return view('site.panel.ticket-detail')->with('ticket',$ticket);
    }
    public function ticketPostReply(Request $request){
        $input = $request->all();
        $ticket = Ticket::find($input['reply_id']);
        $ticket->update([
            'status'=>0
        ]);
        Ticket::create([
            'user_id'=>Auth::id(),
            'reply_id'=>$input['reply_id'],
            'content'=>$input['content']
        ]);
        return redirect()->back()->with('success','پاسخ شما با موفقیت ثبت شد');
    }
    public function ticketCreate(){
        return view('site.panel.ticket-create');
    }
    public function ticketPostCreate(Request $request){
        $input = $request->all();
        Ticket::create([
            'user_id'=>Auth::id(),
            'admin_id'=>1,
            'content'=>$input['content'],
            'subject'=>$input['subject'],
        ]);
        return redirect('/panel/tickets')->with('success','تیکت شما با موفقیت ثبت شد');
    }
    public function transactions(){
        $transactions = Transaction::where('user_id',auth()->user()->id)->get();
        return view('site.panel.transactions')->with('transactions',$transactions);
    }
    public function transactionDetail($id){
        $transaction = Transaction::find($id);
        return view('site.panel.transaction-detail')
            ->with('transaction',$transaction);
    }
    public function orders(){
        $orders = Order::where('user_id',auth()->user()->id)->whereHas('orderItems')->get();
        return view('site.panel.orders')->with('orders',$orders);
    }
    public function orderDetail($id){
        $order = Order::find($id);
        $items = OrderItem::where('order_id',$order->id)->get();
        return view('site.panel.order-detail')
            ->with('order',$order)
            ->with('items',$items);
    }
    public function charge(){
        return view('site.panel.charge');
    }
    public function postCharge(Request $request){
        $input = $request->all();
        $user = User::find(auth()->user()->id);
        $user->update(['charge_price'=>$input['charge_price'],'wallet'=>$user->wallet+$input['charge_price']]);
        return redirect()->back()->with('success','با موفقیت انجام شد');
    }
    public function profile(){
        return view('site.panel.profile');
    }
    public function postProfile(Request $request){
        $input = $request->all();
        $user = User::find(auth()->user()->id);
        if($request->has('password')) {
            if($request->get('password') !== @$request->get('re_password')){
                return redirect()->back()->with('error','تکرار رمز عبور و رمز عبور یکسان نیستند');

            }
            $input['password'] = bcrypt($input['password']);
        }
        $user->update($input);
        return redirect()->back()->with('success','با موفقیت ذخیره شد');
    }
}
