<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Library\MellatBank;
use App\Models\Category;
use App\Models\Country;
use App\Models\CrawledDomains;
use App\Models\Language;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\Profit;
use App\Models\Setting;
use App\Models\Transaction;
use http\Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

use App\User;


class BankController extends Controller
{
    public function chargeBank(Request $request){


        $order = Order::create([
            'user_id'=>Auth::id(),
            'order_status_id'=>2,
            'total_prices'=>$request->charge_price,
            'payment'=>$request->charge_price,
            'type'=>1,
        ]);

        $mellat = new MellatBank();
        $orderDeta = [
            'amount' => intval($order->payment.'0'),
            'order_id' => $order->id,
            'additional_data' => '',
            'back_url'=>'https://landiper.com/back-charge-bank'
        ];
        $resCode = $mellat->startPayment($orderDeta);
        if ($resCode[0] == '0') {

$order->update([
    'ref_id'=>$resCode[1]]);
            Transaction::create([
                'ref_id'=>$resCode[1],
                'user_id'=>Auth::id(),
                'order_id'=>$orderDeta['order_id'],
                'price'=>$orderDeta['amount'],
                'ip'=>$request->ip(),
            ]);


            echo '<form name="myform" action="https://bpm.shaparak.ir/pgwchannel/startpay.mellat" method="POST">
					<input type="hidden" id="RefId" name="RefId" value="'. $resCode[1] .'">
				</form>
				<script type="text/javascript">window.onload = formSubmit; function formSubmit() { document.forms[0].submit(); }</script>';
            exit;
        } else {
            return redirect('/')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
        }

    }
    public function backChargeBank(Request $request){
        if(isset($_POST['ResCode']) && $_POST['ResCode'] == '0'){
            $saleOrderId = $request->get('SaleOrderId');
            $saleReferenceId = $request->get('SaleReferenceId');
            $CardHolderPan = $request->get('CardHolderPan');
            $refId = $request->get('RefId');
            $mellat = new MellatBank();
            $orderDeta = [
                'saleOrderId' => $saleOrderId,
                'saleReferenceId' => $saleReferenceId,
            ];
            $resCode = $mellat->verifyPayment($orderDeta);
            if ($resCode == '0') {
                $resCode = $mellat->settlePayment($orderDeta);
                if ($resCode == '0') {
                     $transaction = Transaction::where('ref_id', $refId)->first();
                     $transaction->tracking_code = $saleReferenceId;
                     $transaction->card_number = $CardHolderPan;
                     $transaction->status = "SUCCEED";
                     $transaction->save();

                    $order = Order::where('ref_id', $refId)->first();
                    $order->update([
                        'order_status_id' => 3,
                        'tracking_code' => $saleReferenceId,
                        'transaction_id' => $transaction->id
                    ]);
                    Auth::loginUsingId($order->user_id);
                    
                     $user = User::find($order->user_id);
                    $user->update([
                        'wallet'=>$user->wallet + $order->payment
                    ]);
            
            
                   return redirect('/panel/transaction/detail/'.$transaction->id)->with('success','پرداخت شما با موفقیت انجام شد!');
                } else {
                    dd($resCode);
                    return redirect('/')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
                }
            } else {

                return redirect('/')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
            }
        }else{
            $order = Order::where('ref_id', $request->get('RefId'))->first();
             Auth::loginUsingId($order->user_id);
                
             $user = User::find($order->user_id);
            return redirect('/panel/charge')->with('error','خطا در پرداخت');
        }
    }
    
    public function shopBank(Request $request,$type){
        if($type == 1){
            $order = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
            $order->update([
                'order_status_id'=>3,
                'payment'=>0.00
            ]);
            $user = User::find(auth()->user()->id);
            $user->update([
                'wallet'=>$user->wallet -  $order->total_prices
            ]);
            return redirect('/panel/order/detail/'.$order->id)->with('success','سفارش شما با موفقیت ثبت شد!');
            
        }elseif($type == 2){
            $order = Order::where('user_id',auth()->user()->id)->currentOrder()->first();
            $order->update([
                'order_status_id'=>2,
                'payment'=>$order->total_prices - auth()->user()->wallet
            ]);
      
    
            $mellat = new MellatBank();
            $orderDeta = [
                'amount' => intval($order->payment.'0'),
                'order_id' => $order->id,
                'additional_data' => '',
                'back_url'=>'https://landiper.com/back-shop-bank'
            ];
            $resCode = $mellat->startPayment($orderDeta);
            if ($resCode[0] == '0') {
    
                $order->update([
                    'ref_id'=>$resCode[1],
               
                ]);
                Transaction::create([
                    'ref_id'=>$resCode[1],
                    'user_id'=>Auth::id(),
                    'order_id'=>$orderDeta['order_id'],
                    'price'=>$orderDeta['amount'],
                    'ip'=>$request->ip(),
                ]);
    
    
                echo '<form name="myform" action="https://bpm.shaparak.ir/pgwchannel/startpay.mellat" method="POST">
    					<input type="hidden" id="RefId" name="RefId" value="'. $resCode[1] .'">
    				</form>
    				<script type="text/javascript">window.onload = formSubmit; function formSubmit() { document.forms[0].submit(); }</script>';
                exit;
            } else {
                return redirect('/')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
            }
            
        }
        

    }
    public function backShopBank(Request $request){
        if(isset($_POST['ResCode']) && $_POST['ResCode'] == '0'){
            $saleOrderId = $request->get('SaleOrderId');
            $saleReferenceId = $request->get('SaleReferenceId');
            $CardHolderPan = $request->get('CardHolderPan');
            $refId = $request->get('RefId');
            $mellat = new MellatBank();
            $orderDeta = [
                'saleOrderId' => $saleOrderId,
                'saleReferenceId' => $saleReferenceId,
            ];
            $resCode = $mellat->verifyPayment($orderDeta);
            if ($resCode == '0') {
                $resCode = $mellat->settlePayment($orderDeta);
                if ($resCode == '0') {
                    $transaction = Transaction::where('ref_id', $refId)->first();
                    $transaction->tracking_code = $saleReferenceId;
                    $transaction->card_number = $CardHolderPan;
                    $transaction->status = "SUCCEED";
                    $transaction->save();

                    $order = Order::where('ref_id', $refId)->first();
                    $order->update([
                        'order_status_id' => 3,
                        'tracking_code' => $saleReferenceId,
                        'transaction_id' => $transaction->id
                    ]);
                    Auth::loginUsingId($order->user_id);
                    
                    return redirect('/panel/transaction/detail/'.$transaction->id)->with('success','پرداخت شما با موفقیت انجام شد!');
                } else {
                       $order = Order::where('ref_id', $request->get('RefId'))->first();
             Auth::loginUsingId($order->user_id);
                
             $user = User::find($order->user_id);
                    return redirect('/panel')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
                }
            } else {
   $order = Order::where('ref_id', $request->get('RefId'))->first();
             Auth::loginUsingId($order->user_id);
                
             $user = User::find($order->user_id);
                return redirect('/panel')->with('error','خطا در پرداخت، مجدد تلاش نمایید.');
            }
        }else{
            $order = Order::where('ref_id', $request->get('RefId'))->first();
             Auth::loginUsingId($order->user_id);
                
             $user = User::find($order->user_id);

            return redirect('/panel')->with('error','خطا در پرداخت');
        }
    }
    
}
