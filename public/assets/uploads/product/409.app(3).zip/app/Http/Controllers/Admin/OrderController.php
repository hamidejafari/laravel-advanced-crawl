<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Library\Sms;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatus;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductStatus;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\ServiceRequest;
use App\Models\Content;

class OrderController extends Controller
{
    public function getIndex(Request $request){

        $query = Order::query();



        if($request->get('order_status_id')){
            $query->where('order_status_id' , $request->get('order_status_id'));

        }
        if($request->get('price_from')){
            $query->whereBetween('total_prices' ,[intval($request->get('price_from')),intval($request->get('price_to'))]);
        }


        if($request->get('user_name')){
            $query->whereHas('user', function (Builder $query)use($request) {
                $query->where('name', 'LIKE', '%' . $request->get('user_name') . '%');
            });
        }
        if($request->get('user_family')){
            $query->whereHas('user', function (Builder $query)use($request) {
                $query->where('family', 'LIKE', '%' . $request->get('user_family') . '%');
            });
        }

        if($request->get('user_mobile')){
            $query->whereHas('user', function (Builder $query)use($request) {
                $query->where('mobile', $request->get('user_mobile') );
            });
        }








        $data = $query->paginate(15);

        $statuses = OrderStatus::where('type',1)->get();
        return view('admin.order.index')
            ->with('statuses' , $statuses)
            ->with('data' , $data);
    }

    public function getDetail($id){
        $data = Order::find($id);
        $status_item = OrderStatus::where('type',2)->get();
        $status_order = OrderStatus::where('type',1)->get();
        return view('admin.order.detail')
            ->with('status_item' , $status_item)
            ->with('status_order' , $status_order)
            ->with('data' , $data);
    }
    public function postChange(Request $request){
        $input = $request->all();
        if($input['type'] == 2){
            $orderItem = OrderItem::find($input['order_item_id'])->update($input);
        }else{
            $order = Order::find($input['order_id'])->update([$input]);
        }
        Sms::orderStatusUser($input['order_id']);
        return redirect()->back()->with('success','با موفقیت ویرایش شد');
    }
}
