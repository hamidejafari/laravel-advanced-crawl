# innertext

```php
innertext ( ) : string
```

Returns the inner text (everything inside the opening and closing tags) of the current node.