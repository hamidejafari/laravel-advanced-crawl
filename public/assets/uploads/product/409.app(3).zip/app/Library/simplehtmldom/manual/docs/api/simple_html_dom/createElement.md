# createElement

```php
createElement ( string $name [, string $value = null ] ) : object
```

Creates a new element.

| Parameter | Description
| --------- | -----------
| `name`    | Name of the element
| `value`   | Value of the element

Returns the element.