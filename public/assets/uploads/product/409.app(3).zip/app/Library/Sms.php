<?php

namespace App\Library;

use App\Models\Order;
use App\Models\Ticket;
use App\User;
use Illuminate\Support\Facades\Log;
use Kavenegar\KavenegarApi;
use Kavenegar\Exceptions\ApiException;
use Kavenegar\Exceptions\HttpException;

class Sms
{

    //website ip :
    private $kavenegarApi;
    private $sender;
    public function __construct()
    {
        $this->kavenegarApi = "4334364A4B7778466C59797747552B31686265706F476E7031776D427730345266326E4C4A3570445531413D";
        $this->sender = "10008663";
    }
    public static function confirmCode($user_id)
    {
        try{
            $user = User::find($user_id);
            $api = new KavenegarApi("4334364A4B7778466C59797747552B31686265706F476E7031776D427730345266326E4C4A3570445531413D");
            $sender ="10008663";
            $message = 'کد فعال سازی اکانت شما در سایت لندیپر ' . $user->mobile_confirm_code . '  میباشد ';
            $receptor = [$user->mobile];
            $result = $api->Send($sender,$receptor,$message);
            return $result;
        }
        catch(ApiException $e){
            \Log::info($e->errorMessage());
            return false;
        }
        catch(HttpException $e){
            \Log::info($e->errorMessage());
            return false;
        }
    }
    public static function orderStatusUser($order_id)
    {
        $order = Order::find($order_id);
        $msg = null;
        $user = User::find($order->user_id);
        $msg = $user->name . ' ' . $user->family . "
        
        ".  " وضعیت سفارش رپورتاژ شما با کد پیگیری " . $order->id . " در سایت لندیپر تغییر کرد, وارد پنل کاربری خود شوید و جزییات آن را مشاهده کنید. ";
        try{
            $api = new KavenegarApi("4334364A4B7778466C59797747552B31686265706F476E7031776D427730345266326E4C4A3570445531413D");
            $sender ="10008663";
            $receptor = [$user->mobile];
            $result = $api->Send($sender,$receptor,$msg);
            return $result;
        }
        catch(ApiException $e){
            \Log::info($e->errorMessage());
            return false;
        }
        catch(HttpException $e){
            \Log::info($e->errorMessage());
            return false;
        }

    }
    public static function ticketUser($ticket_id)
    {
        $ticket = Ticket::find($ticket_id);
        $user = User::find(@$ticket->user_id);
        $msg = @$user->name . ' ' . @$user->family ."
        
        ". " تیکت شما توسط پشتیبانی پاسخ داده شد.  ";
        try{
             $api = new KavenegarApi("4334364A4B7778466C59797747552B31686265706F476E7031776D427730345266326E4C4A3570445531413D");
            $sender ="10008663";
            $receptor = [$user->mobile];
            $result = $api->Send($sender,$receptor,$msg);
            return $result;
        }
        catch(ApiException $e){
            \Log::info($e->errorMessage());
            return false;
        }
        catch(HttpException $e){
            \Log::info($e->errorMessage());
            return false;
        }

    }
}
