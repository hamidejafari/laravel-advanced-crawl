@extends("layouts.site.master")
@section('title'){{$service->title_seo}} @stop
@section('content')
	<div class="header-in bg-custom d-flex align-items-center">
		<div class="container-sm container-md container-lg container-xl container-xxl">
		</div>
	</div>
	<div class="content">
		<div class="container-sm container-md container-lg container-xl container-xxl py-5">
			<div class="row w-100 m-0 gy-3 about-us">
			    <!--<div class="col-xl-6 col-md-10 col-sm-12 m-auto p-1">-->
			    <!--    <div class="bg-white text-center p-3">-->
			    <!--        <img src="{{asset('assets/uploads/service/'.$service->image)}}" class="w-100" alt="{{$service->title}}">-->
			    <!--    </div>-->
			    <!--</div>-->
			    <div class="col-sm-12 m-auto p-1">
    			    <h1 class="text-custom text-center fw-bolder h2 mx-0 my-4">
    					{{$service->title}}
    				</h1>  
    				<div class="text-secondary text-justify">
    				    <p>
        				    {!!$service->description!!}
        				</p>
    				</div>
			    </div>
			</div>
		</div>
	</div>
@endsection
