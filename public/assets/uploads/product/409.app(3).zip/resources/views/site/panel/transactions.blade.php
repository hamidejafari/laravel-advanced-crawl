@extends("site.panel.master")
@section('content')
    <div class="border dashboard-search p-4 mb-0">
        <h4 class="text-custom text-center mb-4">
            لیست تراکنش ها
        </h4>
        <table class="table table-striped m-0">
            <thead>
            <tr>
                <th scope="col" class="text-center text-custom fw-bolder">
                    برای
                </th>
                <th scope="col" class="text-center text-custom fw-bolder">
                   وضعیت
                </th>
                <th scope="col" class="text-center text-custom fw-bolder">
                    کد پیگیری
                </th>
                <th scope="col" class="text-center text-custom fw-bolder">
                    مبلغ پرداختی
                </th>
                <th scope="col" class="text-center text-custom fw-bolder">
                    عملیات
                </th>
            </tr>
            </thead>
            <tbody>
            @foreach($transactions as $row)
                <tr>
                    <th class="text-center" scope="row">
                        {{$row->description ? $row->description : 'سفارش رپورتاژ'}}
                    </th>
                    <td class="text-center">
                        {{$row->status == "SUCCEED" ? 'پرداخت شده و موفقیت آمیز' : 'پرداخت نشده' }}
                    </td>
                    <td class="text-center">
                        {{$row->ref_id }}
                    </td>
                    <td class="text-center">
                        {{number_format($row->price)}} ریال
                    </td>
                    <td class="text-center">
                        <a href="{{route('site.panel.transaction.detail',['id'=>$row->id])}}" class="btn btn-custom-danger rounded-3">
                            <i class="fas fa-eye"></i>
                        </a>

                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection
