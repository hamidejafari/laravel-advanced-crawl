@extends("layouts.site.master")

@section('content')
	<div class="header-in bg-custom d-flex align-items-center">
		<div class="container-sm container-md container-lg container-xl container-xxl">
		</div>
	</div>
	<div class="content">
		<div class="container-sm container-md container-lg container-xl container-xxl py-5">
			<div class="px-3 list-sd">
				<div class="row">
					@foreach($cats as $row)
					<div class="col-xxl-3 col-lg-4 col-sm-6 p-1">
						<a href="{{'/blog/'.$row->url}}" class="text-decoration-none">
							<div class="card shadow border-0 position-relative p-1">
								<div class="overlay shadow position-absolute">
									<span class="text-dark">
									{{jdate('Y/m/d',$row->created_at->timestamp)}}
									</span>
								</div>
								<div class="img-box">
									<img src="{{asset('assets/uploads/content/article/'.$row->image)}}" alt="" class="">
								</div>
								<div class="title-box text-center">
									<h5 class="text-dark my-0">
										{{$row->title}}
									</h5>
								</div>
							</div>
						</a>
					</div>
					@endforeach
				</div>
			</div>
		</div>
	</div>
@endsection
