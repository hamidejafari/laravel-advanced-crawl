@extends("layouts.site.master")
@section('schema')
    {{$article->schema_code}}
@endsection
@section('content')
	<div class="header-in bg-custom d-flex align-items-center">
		<div class="container-sm container-md container-lg container-xl container-xxl">
		</div>
	</div>
	<div class="content">
		<div class="container-sm container-md container-lg container-xl container-xxl py-5">
			<div class="clearfix about-us px-3">
				<h1 class="text-custom fw-bolder">
					{{$article->title}}
				</h1>
				<p>
					{!!$article->description!!}
				</p>
			</div>
		</div>
	</div>
@endsection
