<footer class="main-footer">
    <strong>
        شرکت طراحی وب سایت و اپلیکیشن
        <a href="https://www.rahweb.ir/" class="text-success" target="_blank" rel="noopener noreferrer">
            "ره وب"
        </a>
    </strong>
</footer>
<aside class="control-sidebar control-sidebar-dark"></aside>