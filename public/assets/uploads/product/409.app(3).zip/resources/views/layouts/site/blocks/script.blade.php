<!-- Option 2: Separate Popper and Bootstrap JS -->
<script src="{{asset('assets/site/js/popper.min.js')}}"></script>
<script src="{{asset('assets/site/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/site/js/style.js?v0.02')}}"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
