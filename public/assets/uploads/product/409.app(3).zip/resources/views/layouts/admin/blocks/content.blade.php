<div class="container-fluid">
    @include('layouts.admin.blocks.card-box')
    <div class="row">
        <section class="col-lg-7 connectedSortable">
            
        </section>
        <section class="col-lg-5 connectedSortable">
           
        </section>
    </div>
</div>